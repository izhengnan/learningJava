package zn.practice1114_2;

public interface Shape {
    public double calculateArea();
    public double calculatePerimeter();
}
