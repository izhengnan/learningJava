package zn.practice1114;

public abstract class Maintenance extends Employee{
    public Maintenance(int id, String name) {
        super(id,name);
    }
}
