package zn.practice1114;

public abstract class Development extends Employee{


    public Development(int id, String name) {
        super(id,name);
    }
}
