package zn.practice1121;

public class IllegalScoreException extends Exception{
    public IllegalScoreException(String message){
        super(message);
    }
    public IllegalScoreException(){
    }
}
